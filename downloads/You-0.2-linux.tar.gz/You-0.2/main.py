#!/usr/bin/env python3
import argparse
import sys


def main():
    parser = argparse.ArgumentParser(description="You — браузер для Linux")
    parser.add_argument("--profile", help="Отдельная папка профиля (для тестирования)")
    parser.add_argument("--private", "-p", action="store_true", help="Приватное окно")
    parser.add_argument("addresses", nargs="*", help="Адреса сайтов или поисковые запросы")
    args = parser.parse_args()
    try:
        from browser import YouApplication
    except (ImportError, ValueError) as error:
        print(f"Не удалось загрузить GTK4 / libadwaita / WebKitGTK 6: {error}", file=sys.stderr)
        print("Нужны системные PyGObject, GTK 4.10+, libadwaita 1.5+ и WebKitGTK 6. Запускайте ./run.sh, не Python из виртуального окружения.", file=sys.stderr)
        return 1
    app = YouApplication(profile=args.profile)
    return app.run([sys.argv[0]] + (["--private"] if args.private else []) + args.addresses)


if __name__ == "__main__":
    raise SystemExit(main())
