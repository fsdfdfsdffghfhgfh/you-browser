import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from core import Store, clean_window_state, export_bookmarks_html, parse_bookmarks_html, saved_url
from features import FEATURES, GROUPS, markdown
from test_browser import BrowserFixture, evaluate, wait_for
from browser import BrowserWindow
from gi.repository import Adw, Gtk, Gio


def walk(widget):
    yield widget
    child = widget.get_first_child()
    while child:
        yield from walk(child)
        child = child.get_next_sibling()


def widgets(dialog, kind):
    return [widget for widget in walk(dialog.get_child()) if isinstance(widget, kind)]


class ConvenienceDataTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.store = Store(self.folder.name)

    def tearDown(self):
        self.store.close()
        self.folder.cleanup()

    def test_catalog_is_exactly_500_honest_unique_descriptions(self):
        self.assertEqual(len(FEATURES), 500)
        self.assertEqual(len(GROUPS), 20)
        self.assertEqual(len({item["title"] for item in FEATURES}), 500)
        self.assertEqual([item["id"] for item in FEATURES if item["implemented"]], list(range(1,21)))
        self.assertTrue(all(len(item["description"]) > 35 for item in FEATURES))
        document=markdown()
        self.assertEqual(document.count("**[ГОТОВО]"),20)
        self.assertEqual(document.count("**[ПЛАН]"),480)
        self.assertIn("500. **[ПЛАН]",document)

    def test_session_validation_and_password_redaction(self):
        state = clean_window_state({"tabs":[{"url":"https://user:password@example.org/a","muted":True},
            {"url":"javascript:alert(1)"}, {"url":"https://example.net","pinned":True,"zoom":99},
            {"url":None}], "selected":0})
        self.assertEqual(len(state["tabs"]),3)
        self.assertTrue(state["tabs"][0]["pinned"])
        self.assertEqual(state["tabs"][0]["zoom"],3)
        self.assertNotIn("password",json.dumps(state))
        self.assertIsNone(saved_url("data:text/html,secret"))
        self.assertIsNone(saved_url("https://example.org:invalid"))

    def test_named_sessions_are_persistent_and_not_silently_overwritten(self):
        state={"tabs":[{"url":"https://example.org","muted":True}],"selected":0}
        self.store.save_session("Работа",state)
        with self.assertRaises(ValueError):self.store.save_session("Работа",{"tabs":[{"url":"https://other.org"}]})
        identifier=self.store.sessions()[0]["id"]
        other=Store(self.folder.name)
        try:self.assertEqual(other.load_session(identifier)["tabs"][0]["url"],"https://example.org")
        finally:other.close()
        self.store.delete_session(identifier)
        self.assertIsNone(self.store.load_session(identifier))

    def test_bookmark_import_export_is_safe_and_does_not_replace_titles(self):
        self.store.bookmark("https://example.org","My title")
        text='<DL><A HREF="https://example.org">Replace</A><A HREF="https://second.org/?q=&quot;x&quot;">A &amp; B</A><A HREF="javascript:alert(1)">Bad</A></DL>'
        self.assertEqual(self.store.import_bookmarks(text),1)
        self.assertEqual(self.store.items("bookmarks","My title")[0]["title"],"My title")
        exported=export_bookmarks_html(self.store.items("bookmarks"))
        imported=parse_bookmarks_html(exported)
        self.assertEqual(len(imported),2)
        self.assertIn(("https://second.org/?q=\"x\"","A & B"),imported)

    def test_local_suggestions_deduplicate_bookmarks_and_history(self):
        self.store.visit("https://example.org","Old title")
        self.store.visit("https://example.org","Another title")
        self.store.bookmark("https://example.org","Example")
        self.assertEqual(len(self.store.suggestions("example")),1)
        self.assertEqual(self.store.suggestions("example")[0]["title"],"Example")
        self.assertEqual(self.store.suggestions("x"),[])

    def test_site_zoom_round_trip(self):
        self.store.set_site_zoom("https://example.org/a",1.6)
        self.assertAlmostEqual(self.store.site_zoom("https://example.org/b"),1.6)
        self.assertEqual(self.store.site_zoom("https://other.org"),1)


class ConvenienceBrowserTests(BrowserFixture):
    def loaded_tab(self,path):
        tab=self.window.new_tab(self.url+path)
        wait_for(lambda:tab.webview.get_title()=="You test "+path and not tab.webview.is_loading())
        return tab

    def test_pin_duplicate_mute_reorder_and_bulk_close(self):
        self.window.toggle_pin()
        self.assertTrue(self.tab.page.get_pinned())
        other=self.loaded_tab("/other")
        self.window.toggle_mute()
        self.window.duplicate_tab()
        duplicate=self.window.current_tab()
        self.assertTrue(duplicate.webview.get_is_muted())
        self.assertFalse(duplicate.page.get_pinned())
        self.assertEqual(duplicate.webview.get_uri(),other.webview.get_uri())
        self.window.move_tab(-1)
        self.assertLess(self.window.tab_view.get_page_position(duplicate.page),self.window.tab_view.get_page_position(other.page))
        self.window.mute_others()
        self.assertTrue(self.tab.webview.get_is_muted())
        self.window.close_group(right=True)
        self.assertEqual(self.window.tab_view.get_n_pages(),2)
        self.loaded_tab("/third")
        self.window.close_group()
        self.assertEqual(self.window.tab_view.get_n_pages(),2)  # selected + pinned
        self.assertIn(self.tab,self.window.tabs)

    def test_recent_list_and_undo_keep_mute_and_pin(self):
        self.loaded_tab("/keep")
        self.window.tab_view.set_selected_page(self.tab.page)
        self.window.toggle_pin();self.window.toggle_mute()
        self.window.tab_view.close_page(self.tab.page)
        dialog=self.window.show_recent_tabs()
        row=widgets(dialog,Adw.ActionRow)[0]
        row.emit("activated")
        reopened=self.window.current_tab()
        self.assertTrue(reopened.page.get_pinned())
        self.assertTrue(reopened.webview.get_is_muted())
        self.assertEqual(reopened.webview.get_uri(),self.url+"/first")

    def test_move_to_window_preserves_live_javascript_state(self):
        self.loaded_tab("/keep")
        self.window.tab_view.set_selected_page(self.tab.page)
        evaluate(self.tab.webview,"window.youUnsavedState={value:42}")
        target=self.window.move_to_window()
        try:
            self.assertIs(target.current_view(),self.tab.webview)
            self.assertEqual(evaluate(target.current_view(),"window.youUnsavedState.value"),42)
            self.assertEqual(self.window.tab_view.get_n_pages(),1)
            self.assertIs(self.tab.window,target)
        finally:target.close()

    def test_search_tabs_can_select_another_window_and_hides_private(self):
        other=self.app.new_window(addresses=[self.url+"/target-unique"])
        private=BrowserWindow(self.app,private=True)
        private_tab=private.new_tab(self.url+"/private-unique");private.present()
        try:
            wait_for(lambda:not other.current_view().is_loading() and "target-unique" in (other.current_view().get_title() or ""))
            wait_for(lambda:not private_tab.webview.is_loading() and "private-unique" in (private_tab.webview.get_title() or ""))
            dialog=self.window.show_tab_search()
            search=widgets(dialog,Gtk.SearchEntry)[0]
            search.set_text("private-unique")
            wait_for(lambda:len(widgets(dialog,Adw.ActionRow))==0)
            search.set_text("target-unique")
            wait_for(lambda:len(widgets(dialog,Adw.ActionRow))==1)
            widgets(dialog,Adw.ActionRow)[0].emit("activated")
            self.assertIn("target-unique",other.current_view().get_uri())
        finally:other.close();private.close()

    def test_sidebar_and_bookmark_editing(self):
        self.app.store.bookmark(self.url+"/first","Original")
        self.window.refresh_sidebar()
        if not self.window.sidebar.get_visible():self.window.toggle_sidebar()
        self.assertTrue(self.window.sidebar.get_visible())
        self.window.edit_bookmark({"url":self.url+"/first","title":"Original"})
        dialog=self.window.get_visible_dialog()
        entries=[widget for widget in walk(dialog) if isinstance(widget,Gtk.Entry)]
        self.assertEqual(len(entries),2)
        entries[0].set_text("Edited")
        entries[1].set_text(self.url+"/edited")
        dialog.emit("response","save")
        wait_for(lambda:self.app.store.is_bookmarked(self.url+"/edited"))
        self.assertFalse(self.app.store.is_bookmarked(self.url+"/first"))
        self.assertTrue(self.app.store.items("bookmarks","Edited"))

    def test_session_checkpoint_and_restore_excludes_private(self):
        self.window.toggle_pin()
        second=self.loaded_tab("/restore-target");self.window.toggle_mute()
        private=BrowserWindow(self.app,private=True)
        private.new_tab(self.url+"/do-not-save-private")
        try:
            self.app.checkpoint([self.window,private])
            snapshot=self.app.store.get("last_session")
            self.assertNotIn("do-not-save-private",json.dumps(snapshot))
            self.app.checkpoint([private])
            self.assertEqual(snapshot,self.app.store.get("last_session"))
            before=set(self.app.get_windows())
            self.assertTrue(self.app.restore_last_session())
            restored=next(window for window in self.app.get_windows() if window not in before)
            try:
                self.assertEqual(restored.tab_view.get_n_pages(),2)
                self.assertTrue(restored.tab_view.get_nth_page(0).get_pinned())
                self.assertTrue(restored.current_view().get_is_muted())
                self.assertEqual(restored.current_view().get_uri(),self.url+"/restore-target")
            finally:restored.close()
        finally:private.close()

    def test_named_sessions_ui_and_private_save_guard(self):
        self.window.save_named_session()
        prompt=self.window.get_visible_dialog()
        entry=next(widget for widget in walk(prompt) if isinstance(widget,Gtk.Entry))
        entry.set_text("UI session")
        prompt.emit("response","save")
        wait_for(lambda:bool(self.app.store.sessions()))
        self.assertIn("UI session",[row["name"] for row in self.app.store.sessions()])
        dialog=self.window.show_sessions()
        self.assertTrue(widgets(dialog,Adw.ActionRow))
        dialog.close()
        private=BrowserWindow(self.app,private=True)
        private.new_tab()
        count=len(self.app.store.sessions())
        try:
            private.save_named_session()
            self.assertEqual(len(self.app.store.sessions()),count)
        finally:private.close()

    def test_copy_and_paste_without_touching_user_clipboard(self):
        class Clipboard:
            value=""
            def set_text(self,text):self.value=text
            def read_text_async(self,cancellable,callback):callback(self,None)
            def read_text_finish(self,result):return self.value
        fake=Clipboard()
        self.window.get_clipboard=lambda:fake
        self.window.copy_address();self.assertEqual(fake.value,self.url+"/first")
        fake.value=self.url+"/clipboard"
        self.window.paste_go()
        wait_for(lambda:self.window.current_view().get_title()=="You test /clipboard" and not self.window.current_view().is_loading())

    def test_suggestions_and_catalog_are_available(self):
        self.app.store.bookmark(self.url+"/suggest-unique","Suggestion title")
        self.window.present();self.window.focus_address()
        self.window.address.set_text("suggest-unique")
        wait_for(lambda:self.window.suggestions_box.get_first_child() is not None)
        button=self.window.suggestions_box.get_first_child();button.emit("clicked")
        self.assertEqual(self.window.current_view().get_uri(),self.url+"/suggest-unique")
        dialog=self.window.show_feature_catalog()
        self.assertEqual(len(widgets(dialog,Adw.ActionRow)),500)
        widgets(dialog,Gtk.SearchEntry)[0].set_text("Закрепление вкладок")
        wait_for(lambda:len(widgets(dialog,Adw.ActionRow))==1)
        dialog.close()

    def test_site_zoom_persists_but_private_zoom_does_not(self):
        self.tab.webview.set_zoom_level(1.6)
        self.assertAlmostEqual(self.app.store.site_zoom(self.url),1.6)
        tab=self.loaded_tab("/zoom-target")
        self.assertAlmostEqual(tab.webview.get_zoom_level(),1.6)
        private=BrowserWindow(self.app,private=True)
        page=private.new_tab(self.url+"/private-zoom");private.present()
        try:
            wait_for(lambda:page.webview.get_title()=="You test /private-zoom" and not page.webview.is_loading())
            page.webview.set_zoom_level(1.9)
            self.assertAlmostEqual(self.app.store.site_zoom(self.url),1.6)
        finally:private.close()

    def test_private_transfer_preserves_cookie_context_without_touching_normal_profile(self):
        private=BrowserWindow(self.app,private=True)
        tab=private.new_tab(self.url+"/private-transfer");private.present()
        wait_for(lambda:tab.webview.get_title()=="You test /private-transfer" and not tab.webview.is_loading())
        evaluate(tab.webview,"document.cookie='transfer_secret=private; path=/'")
        source_session=private.session
        target=private.move_to_window()
        try:
            self.assertIs(target.session,source_session)
            self.assertTrue(target.private)
            other=target.new_tab(self.url+"/private-target")
            wait_for(lambda:other.webview.get_title()=="You test /private-target" and not other.webview.is_loading())
            self.assertIn("transfer_secret=private",evaluate(other.webview,"document.cookie"))
            self.assertNotIn("transfer_secret",evaluate(self.tab.webview,"document.cookie"))
            self.assertNotIn("private-transfer",json.dumps(self.app.store.get("last_session",{})))
        finally:target.close()
        self.assertNotIn(source_session,self.app.private_sessions)

    def test_closing_private_window_does_not_erase_last_normal_session(self):
        self.app.checkpoint([self.window])
        snapshot=self.app.store.get("last_session")
        private=BrowserWindow(self.app,private=True);private.new_tab()
        private.close()
        self.assertEqual(snapshot,self.app.store.get("last_session"))

    def test_address_updates_do_not_replace_what_the_user_is_typing(self):
        self.window.focus_address();self.window.address.set_text("my unsent search")
        self.window.sync_toolbar()
        self.assertEqual(self.window.address.get_text(),"my unsent search")

    def test_export_import_and_full_catalog_write_real_files(self):
        folder=Path(self.directory.name)/"export-test";folder.mkdir(exist_ok=True)
        destination=folder/"bookmarks.html"
        class FileDialog:
            def __init__(self,**kwargs):pass
            def save(self,parent,cancellable,callback):callback(self,None)
            def open(self,parent,cancellable,callback):callback(self,None)
            def save_finish(self,result):return Gio.File.new_for_path(str(destination))
            def open_finish(self,result):return Gio.File.new_for_path(str(destination))
        self.app.store.bookmark("https://export-unique.org/","Export <b>")
        with patch.object(Gtk,"FileDialog",FileDialog):
            self.window.export_bookmarks()
            self.assertTrue(destination.is_file())
            self.assertIn("Export &lt;b&gt;",destination.read_text())
            self.app.store.remove_bookmark("https://export-unique.org/")
            self.window.import_bookmarks()
            self.assertTrue(self.app.store.is_bookmarked("https://export-unique.org/"))
            destination=folder/"catalog.md"
            dialog=self.window.show_feature_catalog()
            button=next(widget for widget in widgets(dialog,Gtk.Button) if widget.get_label()=="Сохранить полный каталог в Markdown")
            button.emit("clicked")
            self.assertEqual(destination.read_text(),markdown())
            dialog.close()
