from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os
import gc
import shutil
import ssl
import subprocess
import tempfile
import threading
import time
import unittest

# Headless/virtual desktops may otherwise allocate one llvmpipe worker per CPU
# for every WebKit test process. This changes tests only, not the browser runtime.
os.environ.setdefault("LP_NUM_THREADS", "2")

from browser import BrowserWindow, YouApplication
from gi.repository import Gtk, GLib, WebKit


def wait_for(condition, timeout=15):
    deadline = time.monotonic() + timeout
    context = GLib.MainContext.default()
    while time.monotonic() < deadline:
        while context.pending():
            context.iteration(False)
        if condition():
            return
        time.sleep(0.01)
    raise AssertionError("Timed out waiting for browser state")


def evaluate(view, javascript):
    state = {"done": False}
    def finished(webview, result, *_data):
        try:
            value = webview.evaluate_javascript_finish(result)
            state["value"] = value.to_json(0) if not value.is_undefined() else None
        except GLib.Error as error:
            state["error"] = str(error)
        state["done"] = True
    view.evaluate_javascript(javascript, -1, None, None, None, finished, None)
    wait_for(lambda: state["done"])
    if "error" in state:
        raise AssertionError(state["error"])
    import json
    return json.loads(state["value"]) if state["value"] is not None else None


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        if self.path == "/download":
            body = b"You browser download test\n"
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Disposition", 'attachment; filename="you-browser-test.txt"')
        else:
            body = f"""<!doctype html><title>You test {self.path}</title><h1 id="title">Working browser</h1>
            <a id="next" href="/second">Next page</a><a id="download" href="/download">Download</a>
            <script>document.cookie='you_test=normal; path=/'; document.body.dataset.ready='yes';</script>""".encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


@unittest.skipUnless(Gtk.init_check(), "A graphical display is required")
class BrowserFixture(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        private_tmp = Path("/tmp/.private/mark/opencode")
        cls.directory = tempfile.TemporaryDirectory(prefix="you-test-", dir=private_tmp if private_tmp.is_dir() else None)
        cls.app = YouApplication(profile=cls.directory.name)
        cls.app.register(None)
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.url = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        for window in cls.app.get_windows():
            window.allow_close = True
            window.close()
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()
        # WebKit may still hold open its temporary profile until process exit.
        cls.app.cancel_checkpoint()
        cls.app.stopping = True
        cls.app.store.close()
        cls.directory.cleanup()

    def setUp(self):
        self.window = BrowserWindow(self.app)
        self.tab = self.window.new_tab(self.url + "/first")
        self.window.present()
        wait_for(lambda: self.tab.webview.get_title() == "You test /first" and not self.tab.webview.is_loading())

    def tearDown(self):
        self.window.allow_close = True
        for item in self.window.downloads:
            if item.active:
                item.download.cancel()
        self.window.close()
        gc.collect()
        deadline=time.monotonic()+0.2
        context=GLib.MainContext.default()
        while time.monotonic()<deadline:
            while context.pending():context.iteration(False)
            time.sleep(.01)


class BrowserTests(BrowserFixture):
    def test_navigation_javascript_and_tabs(self):
        view = self.tab.webview
        self.assertEqual(evaluate(view, "document.getElementById('title').textContent"), "Working browser")
        evaluate(view, "document.getElementById('next').click()")
        wait_for(lambda: view.get_title() == "You test /second" and not view.is_loading())
        self.assertTrue(view.can_go_back())
        view.go_back()
        wait_for(lambda: view.get_title() == "You test /first" and not view.is_loading())
        second = self.window.new_tab(self.url + "/second")
        wait_for(lambda: second.webview.get_title() == "You test /second" and not second.webview.is_loading())
        self.assertEqual(self.window.tab_view.get_n_pages(), 2)
        self.window.tab_view.close_page(second.page)
        self.assertEqual(self.window.tab_view.get_n_pages(), 1)
        self.window.reopen_tab()
        self.assertEqual(self.window.tab_view.get_n_pages(), 2)

    def test_bookmark_and_native_dialogs(self):
        self.window.toggle_bookmark()
        self.assertTrue(self.app.store.is_bookmarked(self.url + "/first"))
        self.window.show_collection("bookmarks")
        self.window.show_settings()
        self.window.show_about()
        self.window.show_find()
        self.window.find_entry.set_text("Working")
        wait_for(lambda: "1" in self.window.find_count.get_text())
        self.window.hide_find()
        self.window.zoom(.1)
        self.assertAlmostEqual(self.tab.webview.get_zoom_level(), 1.1)

    def test_private_history_and_cookie_isolation(self):
        self.assertIn("you_test=normal", evaluate(self.tab.webview, "document.cookie"))
        private = BrowserWindow(self.app, private=True)
        private_tab = private.new_tab(self.url + "/private-only")
        private.present()
        try:
            wait_for(lambda: private_tab.webview.get_title() == "You test /private-only" and not private_tab.webview.is_loading())
            evaluate(private_tab.webview, "document.cookie='private_only=yes; path=/'")
            self.assertNotIn("private_only", evaluate(self.tab.webview, "document.cookie"))
            self.assertFalse(any("private-only" in row["url"] for row in self.app.store.items("history")))
            self.assertTrue(private.session.is_ephemeral())
        finally:
            private.close()

    def test_home_page_and_search(self):
        self.window.go_home()
        wait_for(lambda: self.tab.webview.get_title() == "Новая вкладка — You" and not self.tab.webview.is_loading())
        self.assertEqual(evaluate(self.tab.webview, "document.querySelector('form').action"), "https://duckduckgo.com/")
        self.assertTrue(self.tab.is_home)

    def test_real_download(self):
        # Keep tests out of the user's Downloads directory.
        import browser
        original = browser.GLib.get_user_special_dir
        target = Path(self.directory.name) / "downloads"
        browser.GLib.get_user_special_dir = lambda category: str(target)
        try:
            self.window.session.download_uri(self.url + "/download")
            wait_for(lambda: bool(self.window.downloads) and not self.window.downloads[-1].active)
            item = self.window.downloads[-1]
            self.assertFalse(item.failed, item.status.get_text())
            self.assertEqual(item.path.read_bytes(), b"You browser download test\n")
        finally:
            browser.GLib.get_user_special_dir = original

    @unittest.skipUnless(shutil.which("openssl"), "OpenSSL is required for the TLS test")
    def test_invalid_https_certificate_is_blocked(self):
        folder = Path(self.directory.name) / "tls"
        folder.mkdir(exist_ok=True)
        certificate, key = folder / "certificate.pem", folder / "key.pem"
        subprocess.run([
            "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1",
            "-subj", "/CN=localhost", "-addext", "subjectAltName=IP:127.0.0.1",
            "-out", str(certificate), "-keyout", str(key),
        ], check=True, capture_output=True)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(certificate, key)
        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        server.socket = context.wrap_socket(server.socket, server_side=True)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = f"https://127.0.0.1:{server.server_port}/untrusted"
        try:
            self.tab.open(url)
            wait_for(lambda: self.tab.is_error and not self.tab.webview.is_loading())
            self.assertEqual(self.tab.content_stack.get_visible_child_name(), "error")
            self.assertIn("сертификат", self.tab.error_status.get_description())
            self.assertFalse(any(row["url"] == url for row in self.app.store.items("history")))
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


if __name__ == "__main__":
    unittest.main()
