from pathlib import Path
import tempfile
import unittest

from core import Store, display_address, error_html, home_html, resolve_address, unique_download_path


class AddressTests(unittest.TestCase):
    def test_addresses(self):
        examples = {
            "": None,
            "you://home": None,
            "example.org/path": "https://example.org/path",
            "localhost:8000": "http://localhost:8000",
            "127.0.0.1:8000/page": "http://127.0.0.1:8000/page",
            "192.168.2.88:8443": "http://192.168.2.88:8443",
            "[::1]:8000/": "http://[::1]:8000/",
            "https://пример.рф/путь": "https://xn--e1afmkfd.xn--p1ai/%D0%BF%D1%83%D1%82%D1%8C",
            "https://example.org/a b?q=hello world": "https://example.org/a%20b?q=hello%20world",
        }
        for text, expected in examples.items():
            with self.subTest(text=text):
                self.assertEqual(resolve_address(text), expected)

    def test_search_and_unsafe_input(self):
        self.assertEqual(resolve_address("привет мир", "yandex"), "https://yandex.ru/search/?text=%D0%BF%D1%80%D0%B8%D0%B2%D0%B5%D1%82+%D0%BC%D0%B8%D1%80")
        for text in ("javascript:alert(1)", "data:text/html,test", "cats & dogs", "example.org:invalid", "me@example.org"):
            self.assertTrue(resolve_address(text).startswith("https://duckduckgo.com/?q="))

    def test_redact_password_and_escape_errors(self):
        self.assertEqual(display_address("https://user:secret@example.org/path"), "https://example.org/path")
        page = error_html("https://example.org/?q=<script>", "<img onerror=alert(1)>")
        self.assertNotIn("<script>", page)
        self.assertNotIn("<img onerror", page)

    def test_safe_download_filenames(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.assertEqual(unique_download_path(root, "../../report.pdf"), root / "report.pdf")
            self.assertEqual(unique_download_path(root, "..\\..\\report.pdf"), root / "report.pdf")
            (root / "report.pdf").touch()
            self.assertEqual(unique_download_path(root, "report.pdf"), root / "report (1).pdf")
            self.assertEqual(unique_download_path(root, ".."), root / "download")


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.store = Store(self.directory.name)

    def tearDown(self):
        self.store.close()
        self.directory.cleanup()

    def test_settings_and_persistence(self):
        self.store.set("search_engine", "google")
        self.store.bookmark("https://example.org", "Example")
        other = Store(self.directory.name)
        try:
            self.assertEqual(other.get("search_engine"), "google")
            self.assertTrue(other.is_bookmarked("https://example.org"))
        finally:
            other.close()

    def test_bookmarks_history_and_literal_search(self):
        self.store.bookmark("https://example.org", "100% <test>")
        self.assertFalse(self.store.bookmark("javascript:alert(1)", "Unsafe"))
        self.store.visit("https://example.org", "Hello")
        self.assertEqual(len(self.store.items("bookmarks", "%")), 1)
        self.assertEqual(len(self.store.items("bookmarks", "' OR 1=1 --")), 0)
        self.assertEqual(len(self.store.items("history")), 1)
        self.store.clear_history()
        self.assertEqual(len(self.store.items("history")), 0)
        self.assertTrue(self.store.is_bookmarked("https://example.org"))
        self.assertIn("100% &lt;test&gt;", home_html(self.store))
        self.store.remove_bookmark("https://example.org")
        self.assertFalse(self.store.is_bookmarked("https://example.org"))


if __name__ == "__main__":
    unittest.main()
