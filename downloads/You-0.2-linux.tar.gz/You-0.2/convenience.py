"""Convenience features, kept separate from WebKit navigation and permissions."""

from datetime import datetime
from pathlib import Path
import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk

from core import clean_window_state, display_address, export_bookmarks_html, saved_url


class ConvenienceMixin:
    def wrap_content(self, page):
        self.sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, width_request=260)
        self.sidebar.add_css_class("bookmarks-sidebar")
        heading = Gtk.Box(spacing=8)
        heading.append(Gtk.Label(label="Закладки", hexpand=True, xalign=0, css_classes=["heading"]))
        close = Gtk.Button(icon_name="sidebar-hide-symbolic", tooltip_text="Скрыть панель")
        close.connect("clicked", lambda button: self.toggle_sidebar())
        heading.append(close)
        self.sidebar.append(heading)
        self.sidebar_search = Gtk.SearchEntry(placeholder_text="Найти закладку")
        self.sidebar_search.connect("search-changed", lambda entry: self.refresh_sidebar())
        self.sidebar.append(self.sidebar_search)
        self.sidebar_rows = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        self.sidebar_rows.add_css_class("boxed-list")
        scroll = Gtk.ScrolledWindow(vexpand=True)
        scroll.set_child(self.sidebar_rows)
        self.sidebar.append(scroll)
        self.sidebar.set_visible(bool(self.app.store.get("sidebar_visible", False)))
        split = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL, position=280)
        split.set_start_child(self.sidebar)
        split.set_end_child(page)
        split.set_resize_start_child(False)
        split.set_shrink_start_child(False)
        self.refresh_sidebar()
        return split

    def init_convenience(self):
        self._syncing_address = False
        self.suggestions_popover = Gtk.Popover(autohide=False, has_arrow=False, focusable=False)
        self.suggestions_popover.set_parent(self.address)
        self.suggestions_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, width_request=420)
        self.suggestions_popover.set_child(self.suggestions_box)
        self.address.connect("changed", self._suggestions_changed)
        focus = Gtk.EventControllerFocus()
        focus.connect("leave", lambda controller: self.suggestions_popover.popdown())
        self.address.add_controller(focus)
        context = Gio.Menu()
        for label, action in (("Дублировать", "duplicate-tab"), ("Закрепить / открепить", "pin-tab"),
                              ("Выключить / включить звук", "mute-tab"), ("Заглушить остальные", "mute-others"),
                              ("Закрыть справа", "close-right"), ("Закрыть остальные незакреплённые", "close-others"),
                              ("Перенести в новое окно", "move-window"), ("Сдвинуть влево", "move-left"),
                              ("Сдвинуть вправо", "move-right"), ("Скопировать адрес", "copy-address")):
            context.append(label, "win." + action)
        self.tab_view.set_menu_model(context)
        self.tab_view.connect("setup-menu", self._tab_context)
        self.tab_view.connect("page-reordered", lambda *args: self.app.schedule_checkpoint())
        self.tab_view.connect("indicator-activated", lambda view, page: page.get_child().webview.set_is_muted(not page.get_child().webview.get_is_muted()))

    def convenience_menu(self):
        menu = Gio.Menu()
        for label, action in (("Найти вкладку", "search-tabs"), ("Недавно закрытые вкладки", "recent-tabs"),
                              ("Боковая панель закладок", "sidebar"), ("Сохранить набор вкладок", "save-session"),
                              ("Сохранённые наборы", "sessions"), ("Импорт закладок…", "import-bookmarks"),
                              ("Экспорт закладок…", "export-bookmarks"), ("Скопировать адрес", "copy-address"),
                              ("Вставить и перейти", "paste-go"), ("Каталог 500 возможностей", "feature-catalog")):
            menu.append(label, "win." + action)
        return menu

    def convenience_actions(self):
        return {
            "duplicate-tab": (self.duplicate_tab, ["<Primary><Shift>d"]),
            "pin-tab": (self.toggle_pin, ["<Primary><Shift>p"]),
            "mute-tab": (self.toggle_mute, ["<Primary>m"]),
            "mute-others": (self.mute_others, []),
            "close-right": (lambda: self.close_group(right=True), []),
            "close-others": (lambda: self.close_group(right=False), []),
            "move-window": (self.move_to_window, []),
            "move-left": (lambda: self.move_tab(-1), ["<Primary><Shift>Page_Up"]),
            "move-right": (lambda: self.move_tab(1), ["<Primary><Shift>Page_Down"]),
            "search-tabs": (self.show_tab_search, ["<Primary><Shift>a"]),
            "recent-tabs": (self.show_recent_tabs, []),
            "sidebar": (self.toggle_sidebar, ["<Primary>b"]),
            "copy-address": (self.copy_address, ["<Primary><Shift>c"]),
            "paste-go": (self.paste_go, ["<Primary><Shift>l"]),
            "save-session": (self.save_named_session, []),
            "sessions": (self.show_sessions, []),
            "import-bookmarks": (self.import_bookmarks, []),
            "export-bookmarks": (self.export_bookmarks, []),
            "feature-catalog": (self.show_feature_catalog, []),
        }

    def _tab_context(self, view, page):
        if page:
            view.set_selected_page(page)

    def tab_state(self, tab):
        return {"url": saved_url(tab.failed_uri if tab.is_error else tab.webview.get_uri()),
                "title": tab.page.get_title(), "pinned": tab.page.get_pinned(),
                "muted": tab.webview.get_is_muted(), "zoom": tab.webview.get_zoom_level()}

    def window_state(self):
        pages = [self.tab_view.get_nth_page(index) for index in range(self.tab_view.get_n_pages())]
        return {"tabs": [self.tab_state(page.get_child()) for page in pages],
                "selected": self.tab_view.get_page_position(self.tab_view.get_selected_page()) if pages else 0}

    def restore_state(self, state):
        state = clean_window_state(state)
        for item in state["tabs"]:
            self.new_tab(item["url"], select=False, state=item)
        if state["tabs"]:
            self.tab_view.set_selected_page(self.tab_view.get_nth_page(state["selected"]))
        else:
            self.new_tab()

    def duplicate_tab(self):
        if self.current_tab():
            state = self.tab_state(self.current_tab())
            state["pinned"] = False
            self.new_tab(state["url"], state=state)

    def toggle_pin(self):
        page = self.tab_view.get_selected_page()
        if page:
            self.tab_view.set_page_pinned(page, not page.get_pinned())
            self.app.schedule_checkpoint()

    def toggle_mute(self):
        view = self.current_view()
        if view:
            view.set_is_muted(not view.get_is_muted())

    def mute_others(self):
        for tab in self.tabs:
            if tab is not self.current_tab():
                tab.webview.set_is_muted(True)
        self.toast("Остальные вкладки этого окна заглушены")

    def close_group(self, right=False):
        current = self.tab_view.get_selected_page()
        position = self.tab_view.get_page_position(current)
        pages = [self.tab_view.get_nth_page(index) for index in range(self.tab_view.get_n_pages())]
        for index,page in enumerate(pages):
            if page != current and not page.get_pinned() and (not right or index > position):
                self.tab_view.close_page(page)

    def move_tab(self, offset):
        page = self.tab_view.get_selected_page()
        if page:
            self.tab_view.reorder_backward(page) if offset < 0 else self.tab_view.reorder_forward(page)

    def move_to_window(self):
        tab = self.current_tab()
        if not tab:
            return None
        target = self.app.new_window(private=self.private, empty=True, session=self.session if self.private else None)
        self.tabs.remove(tab)
        target.tabs.append(tab)
        tab.window = target
        self.app.view_windows[tab.webview] = target
        self.tab_view.transfer_page(tab.page, target.tab_view, 0)
        target.tab_view.set_selected_page(tab.page)
        target.sync_toolbar(force_address=True)
        if not self.tabs:
            if any(item.active for item in self.downloads):
                self.new_tab()
                self.toast("Загрузки остаются в этом окне")
            else:
                self.close()
        self.app.schedule_checkpoint()
        return target

    def show_tab_search(self):
        dialog, content = self._dialog("Найти открытую вкладку")
        search = Gtk.SearchEntry(placeholder_text="Название или адрес")
        content.append(search)
        rows = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        rows.add_css_class("boxed-list")
        scroll = Gtk.ScrolledWindow(vexpand=True, child=rows)
        content.append(scroll)
        def rebuild(*args):
            while rows.get_first_child():
                rows.remove(rows.get_first_child())
            query = search.get_text().casefold()
            for window in self.app.get_windows():
                if not hasattr(window, "tabs") or window.private != self.private or window.closing:
                    continue
                for tab in window.tabs:
                    title = tab.page.get_title()
                    url = display_address(tab.webview.get_uri() or "")
                    if query not in (title + " " + url).casefold():
                        continue
                    row = Adw.ActionRow(title=title, subtitle=url, use_markup=False, activatable=True)
                    row.set_title_lines(1)
                    row.set_subtitle_lines(1)
                    def select(row, target=window, page=tab.page):
                        if page.get_child() in target.tabs:
                            target.tab_view.set_selected_page(page)
                            target.present()
                        dialog.close()
                    row.connect("activated", select)
                    rows.append(row)
        search.connect("search-changed", rebuild)
        rebuild()
        dialog.present(self)
        search.grab_focus()
        return dialog

    def show_recent_tabs(self):
        dialog, content = self._dialog("Недавно закрытые вкладки этого окна")
        rows = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        rows.add_css_class("boxed-list")
        content.append(Gtk.ScrolledWindow(child=rows, vexpand=True))
        if not self.closed_tabs:
            rows.append(Gtk.Label(label="Закрытых вкладок пока нет", margin_top=25, margin_bottom=25))
        for state in reversed(self.closed_tabs):
            row = Adw.ActionRow(title=state["title"] or "Новая вкладка", subtitle=display_address(state["url"] or ""), use_markup=False, activatable=True)
            row.set_title_lines(1)
            row.set_subtitle_lines(1)
            def restore(row, item=state):
                self.new_tab(item["url"], state=item)
                self.closed_tabs = [value for value in self.closed_tabs if value is not item]
                dialog.close()
            row.connect("activated", restore)
            rows.append(row)
        dialog.present(self)
        return dialog

    def copy_address(self):
        tab = self.current_tab()
        if tab:
            url = saved_url(tab.failed_uri if tab.is_error else tab.webview.get_uri())
            if url:
                self.get_clipboard().set_text(url)
                self.toast("Адрес скопирован")

    def paste_go(self):
        def read(clipboard, result, *_data):
            try:
                text = clipboard.read_text_finish(result)
                if text and not self.closing:
                    from core import resolve_address
                    self.open_url(resolve_address(text, self.app.store.get("search_engine", "duckduckgo")))
            except GLib.Error as error:
                self.toast(error.message)
        self.get_clipboard().read_text_async(None, read)

    def toggle_sidebar(self):
        visible = not self.sidebar.get_visible()
        self.sidebar.set_visible(visible)
        if not self.private:
            self.app.store.set("sidebar_visible", visible)
        if visible:
            self.refresh_sidebar()

    def refresh_sidebar(self):
        if not hasattr(self, "sidebar_rows"):
            return
        while self.sidebar_rows.get_first_child():
            self.sidebar_rows.remove(self.sidebar_rows.get_first_child())
        items = self.app.store.items("bookmarks", self.sidebar_search.get_text())
        for item in items:
            row = Adw.ActionRow(title=item["title"], subtitle=display_address(item["url"]), use_markup=False, activatable=True)
            row.set_title_lines(1)
            row.set_subtitle_lines(1)
            row.connect("activated", lambda row, url=item["url"]: self.open_url(url))
            edit = Gtk.Button(icon_name="document-edit-symbolic", valign=Gtk.Align.CENTER, tooltip_text="Изменить закладку")
            edit.connect("clicked", lambda button, value=dict(item): self.edit_bookmark(value))
            row.add_suffix(edit)
            self.sidebar_rows.append(row)
        if not items:
            self.sidebar_rows.append(Gtk.Label(label="Нет закладок", margin_top=20, margin_bottom=20))

    def edit_bookmark(self, item):
        dialog = Adw.AlertDialog(heading="Изменить закладку")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        title = Gtk.Entry(text=item["title"], placeholder_text="Название")
        address = Gtk.Entry(text=item["url"], placeholder_text="Полный адрес сайта")
        box.append(title)
        box.append(address)
        dialog.set_extra_child(box)
        dialog.add_response("cancel", "Отмена")
        dialog.add_response("save", "Сохранить")
        dialog.set_close_response("cancel")
        def done(prompt, result, *_data):
            if prompt.choose_finish(result) != "save":
                return
            url = saved_url(address.get_text().strip())
            if not url:
                self.toast("Нужен полный http://, https:// или file:// адрес")
                return
            if url != item["url"] and self.app.store.is_bookmarked(url):
                self.toast("Такая закладка уже есть; существующая не изменена")
                return
            self.app.store.bookmark(url, title.get_text().strip() or url)
            if url != item["url"]:
                self.app.store.remove_bookmark(item["url"])
            self.app.refresh_bookmarks()
        dialog.choose(self, None, done)

    def _suggestions_changed(self, entry):
        if self._syncing_address or not self.address_has_focus():
            return
        while self.suggestions_box.get_first_child():
            self.suggestions_box.remove(self.suggestions_box.get_first_child())
        items = self.app.store.suggestions(entry.get_text())
        if not items:
            self.suggestions_popover.popdown()
            return
        for item in items:
            button = Gtk.Button(label=item["title"][:75]+"\n"+display_address(item["url"])[:90], focus_on_click=False, focusable=False)
            button.add_css_class("flat")
            button.connect("clicked", lambda button, url=item["url"]: (self.suggestions_popover.popdown(), self.open_url(url)))
            self.suggestions_box.append(button)
        self.suggestions_popover.popup()

    def address_has_focus(self):
        # Gtk.Entry delegates keyboard focus to its internal Gtk.Text widget.
        focused = self.get_focus()
        return focused is self.address or bool(focused and focused.is_ancestor(self.address))

    def save_named_session(self):
        if self.private:
            self.toast("Приватные вкладки не сохраняются в наборы")
            return
        dialog = Adw.AlertDialog(heading="Сохранить набор вкладок", body="Сохраняются адреса, порядок, закрепление и звук. Заполненные формы не сохраняются.")
        name = Gtk.Entry(text=datetime.now().strftime("Набор %d.%m %H:%M"))
        dialog.set_extra_child(name)
        dialog.add_response("cancel", "Отмена")
        dialog.add_response("save", "Сохранить")
        dialog.set_close_response("cancel")
        def done(prompt, result, *_data):
            if prompt.choose_finish(result) == "save":
                try:
                    self.app.store.save_session(name.get_text(), self.window_state())
                    self.toast("Набор вкладок сохранён")
                except ValueError as error:
                    self.toast(str(error))
        dialog.choose(self, None, done)

    def show_sessions(self):
        dialog, content = self._dialog("Сохранённые наборы вкладок")
        rows = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        rows.add_css_class("boxed-list")
        content.append(Gtk.ScrolledWindow(child=rows, vexpand=True))
        def rebuild():
            while rows.get_first_child():
                rows.remove(rows.get_first_child())
            items = self.app.store.sessions()
            for item in items:
                row = Adw.ActionRow(title=item["name"], use_markup=False, activatable=True, subtitle="Открыть в новом окне")
                def load(row, identifier=item["id"]):
                    state = self.app.store.load_session(identifier)
                    if state:
                        window = self.app.new_window(private=self.private, empty=True)
                        window.restore_state(state)
                    dialog.close()
                row.connect("activated", load)
                remove = Gtk.Button(icon_name="user-trash-symbolic", valign=Gtk.Align.CENTER, tooltip_text="Удалить набор")
                def delete(button, identifier=item["id"], name=item["name"]):
                    prompt = Adw.AlertDialog(heading="Удалить набор?", body=name)
                    prompt.add_response("cancel", "Отмена")
                    prompt.add_response("delete", "Удалить")
                    prompt.set_close_response("cancel")
                    prompt.set_response_appearance("delete", Adw.ResponseAppearance.DESTRUCTIVE)
                    def done(alert, result, *_data):
                        if alert.choose_finish(result)=="delete":
                            self.app.store.delete_session(identifier)
                            rebuild()
                    prompt.choose(self, None, done)
                remove.connect("clicked", delete)
                row.add_suffix(remove)
                rows.append(row)
            if not items:
                rows.append(Gtk.Label(label="Сохранённых наборов пока нет", margin_top=25, margin_bottom=25))
        rebuild()
        dialog.present(self)
        return dialog

    def export_bookmarks(self):
        chooser = Gtk.FileDialog(title="Экспорт закладок", initial_name="You-bookmarks.html")
        def selected(dialog, result, *_data):
            try:
                file = dialog.save_finish(result)
                file.replace_contents(export_bookmarks_html(self.app.store.items("bookmarks", limit=10000)).encode(), None, False, Gio.FileCreateFlags.NONE, None)
                self.toast("Закладки экспортированы")
            except GLib.Error as error:
                if not error.matches(Gio.io_error_quark(), Gio.IOErrorEnum.CANCELLED):
                    self.toast(error.message)
        chooser.save(self, None, selected)

    def import_bookmarks(self):
        chooser = Gtk.FileDialog(title="Импорт закладок из HTML")
        def selected(dialog, result, *_data):
            try:
                file = dialog.open_finish(result)
                path = file.get_path()
                if not path or Path(path).stat().st_size > 10_000_000:
                    raise ValueError("Нужен локальный HTML-файл до 10 МБ")
                count = self.app.store.import_bookmarks(Path(path).read_text(encoding="utf-8-sig", errors="replace"))
                self.app.refresh_bookmarks()
                self.toast(f"Добавлено закладок: {count}. Существующие не заменены.")
            except (OSError, ValueError) as error:
                self.toast(str(error))
            except GLib.Error as error:
                if not error.matches(Gio.io_error_quark(), Gio.IOErrorEnum.CANCELLED):
                    self.toast(error.message)
        chooser.open(self, None, selected)

    def show_feature_catalog(self):
        from features import FEATURES, markdown
        dialog, content = self._dialog("500 возможностей You · готово / план")
        export_button=Gtk.Button(label="Сохранить полный каталог в Markdown")
        def export(button):
            chooser=Gtk.FileDialog(title="Сохранить каталог 500 возможностей",initial_name="You-500-features.md")
            def selected(file_dialog,result,*_data):
                try:
                    file=file_dialog.save_finish(result)
                    file.replace_contents(markdown().encode(),None,False,Gio.FileCreateFlags.NONE,None)
                    self.toast("Все 500 описаний сохранены")
                except GLib.Error as error:
                    if not error.matches(Gio.io_error_quark(),Gio.IOErrorEnum.CANCELLED):
                        self.toast(error.message)
            chooser.save(self,None,selected)
        export_button.connect("clicked",export)
        content.append(export_button)
        search = Gtk.SearchEntry(placeholder_text="Поиск по названию или описанию")
        content.append(search)
        rows = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        rows.add_css_class("boxed-list")
        content.append(Gtk.ScrolledWindow(child=rows, vexpand=True))
        content.prepend(Gtk.Label(label="Реализована первая партия из 20 функций. Остальные 480 — план, не готовые кнопки.", wrap=True, xalign=0))
        def rebuild(*args):
            while rows.get_first_child():
                rows.remove(rows.get_first_child())
            query = search.get_text().casefold()
            for feature in FEATURES:
                if query not in (feature["title"]+" "+feature["description"]+" "+feature["category"]).casefold():
                    continue
                status = "Готово" if feature["implemented"] else "План"
                row = Adw.ActionRow(title=f'{feature["id"]:03d} · {feature["title"]}', subtitle=feature["description"], use_markup=False)
                row.set_subtitle_lines(3)
                row.add_suffix(Gtk.Label(label=status, css_classes=["success" if feature["implemented"] else "dim-label"]))
                rows.append(row)
        search.connect("search-changed", rebuild)
        rebuild()
        dialog.present(self)
        return dialog
