#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
exec /usr/bin/python3 main.py "$@"
