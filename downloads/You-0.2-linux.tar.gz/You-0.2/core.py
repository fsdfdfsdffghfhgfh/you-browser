"""Browser data and address parsing; no GUI dependencies."""

from html import escape
from html.parser import HTMLParser
import ipaddress
import json
from pathlib import Path
import re
import sqlite3
import time
from urllib.parse import quote, quote_plus, urlsplit, urlunsplit

ROOT = Path(__file__).resolve().parent
SEARCH_ENGINES = {
    "duckduckgo": ("DuckDuckGo", "https://duckduckgo.com/", "q"),
    "google": ("Google", "https://www.google.com/search", "q"),
    "yandex": ("Яндекс", "https://yandex.ru/search/", "text"),
}


def search_url(text, engine="duckduckgo"):
    _, action, field = SEARCH_ENGINES.get(engine, SEARCH_ENGINES["duckduckgo"])
    return f"{action}?{field}={quote_plus(text)}"


def resolve_address(text, engine="duckduckgo"):
    """Return a navigable URL, or None for a new tab. Never execute shell/JS input."""
    text = text.strip()
    if not text or text.lower() in ("you://home", "you://newtab", "about:blank"):
        return None
    if text.startswith(("/", "~/")):
        return Path(text).expanduser().absolute().as_uri()
    if text.lower().startswith("file://"):
        return text
    explicit = re.match(r"^https?://", text, re.I)
    if not explicit:
        if "@" in text.split("/", 1)[0]:
            return search_url(text, engine)
        if any(character.isspace() for character in text) or re.match(r"^[a-z][a-z0-9+.-]*:", text, re.I) and not re.match(r"^[^/:]+:\d+(?:/|$)", text):
            return search_url(text, engine)
        host = text.split("/", 1)[0].split("?", 1)[0].split("#", 1)[0]
        if not ("." in host or host.startswith(("localhost", "["))):
            return search_url(text, engine)
        try:
            candidate = urlsplit("https://" + text)
            hostname = candidate.hostname or ""
            local = hostname == "localhost" or hostname.endswith(".local")
            try:
                local |= ipaddress.ip_address(hostname).is_private
            except ValueError:
                pass
            text = ("http://" if local else "https://") + text
        except ValueError:
            return search_url(text, engine)
    try:
        parts = urlsplit(text)
        host = parts.hostname
        port = parts.port  # Also validates invalid/out-of-range ports.
        if not host:
            return search_url(text, engine)
        host = f"[{host}]" if ":" in host else host.encode("idna").decode("ascii")
        authority = host + (f":{port}" if port is not None else "")
        if "@" in parts.netloc:
            authority = parts.netloc.rsplit("@", 1)[0] + "@" + authority
        return urlunsplit((parts.scheme.lower(), authority,
                          quote(parts.path, safe="/%:@!$&'()*+,;=-._~"),
                          quote(parts.query, safe="%=&?/+:;,@!$'()*[]-._~"),
                          quote(parts.fragment, safe="%/?@:!$&'()*+,;=-._~")))
    except (ValueError, UnicodeError):
        return search_url(text, engine)


def display_address(url):
    """Do not display embedded passwords in the location field or error pages."""
    try:
        parts = urlsplit(url)
        if "@" in parts.netloc:
            return urlunsplit((parts.scheme, parts.netloc.rsplit("@", 1)[1], parts.path, parts.query, parts.fragment))
    except ValueError:
        pass
    return url


def origin(url):
    try:
        parts = urlsplit(url)
        return (parts.scheme, parts.hostname, parts.port)
    except ValueError:
        return ("", "", None)


def unique_download_path(directory, name):
    directory = Path(directory)
    # A server-supplied filename must not escape the Downloads folder.
    name = name.replace("\\", "/").split("/")[-1].replace("\x00", "").strip()
    if not name or name in (".", ".."):
        name = "download"
    name = re.sub(r"[\x01-\x1f\x7f]", "_", name)[:180]
    candidate = directory / name
    number = 1
    while candidate.exists():
        item = Path(name)
        candidate = directory / f"{item.stem} ({number}){item.suffix}"
        number += 1
    return candidate


def saved_url(value):
    """Only restore ordinary user pages; never execute a stored script/data URL."""
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = urlsplit(value)
        if parsed.scheme not in ("http", "https", "file"):
            return None
        if parsed.scheme != "file" and not parsed.hostname:
            return None
        parsed.port
    except ValueError:
        return None
    return display_address(value)


def clean_window_state(value):
    if not isinstance(value, dict) or not isinstance(value.get("tabs"), list):
        return {"tabs": [], "selected": 0}
    tabs = []
    for item in value["tabs"][:200]:
        if not isinstance(item, dict):
            continue
        url = saved_url(item.get("url"))
        if item.get("url") and url is None:
            continue
        try:
            zoom = max(0.5, min(3, float(item.get("zoom", 1))))
        except (ValueError, TypeError):
            zoom = 1
        tabs.append({"url": url, "title": str(item.get("title", ""))[:300],
                     "pinned": bool(item.get("pinned")), "muted": bool(item.get("muted")), "zoom": zoom})
    # Native pinned tabs are always grouped before the rest.
    selected_item = None
    try:
        selected_item = tabs[max(0, min(len(tabs)-1, int(value.get("selected", 0))))] if tabs else None
    except (ValueError, TypeError):
        pass
    tabs.sort(key=lambda item: not item["pinned"])
    selected = next((index for index,item in enumerate(tabs) if item is selected_item), 0)
    return {"tabs": tabs, "selected": selected}


class BookmarkParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.items = []
        self.current = None

    def handle_starttag(self, tag, attributes):
        if tag.lower() == "a":
            attributes = dict(attributes)
            url = saved_url(attributes.get("href"))
            self.current = {"url": url, "title": ""} if url else None

    def handle_data(self, data):
        if self.current:
            self.current["title"] += data[:1000]

    def handle_endtag(self, tag):
        if tag.lower() == "a" and self.current:
            if len(self.items) < 5000:
                self.items.append((self.current["url"], self.current["title"].strip() or self.current["url"]))
            self.current = None


def parse_bookmarks_html(text):
    if len(text) > 10_000_000:
        raise ValueError("Файл закладок слишком большой (максимум 10 МБ)")
    parser = BookmarkParser()
    parser.feed(text)
    return parser.items


def export_bookmarks_html(items):
    rows = "\n".join(f'<DT><A HREF="{escape(row["url"], quote=True)}">{escape(row["title"])}</A>' for row in items)
    return '<!DOCTYPE NETSCAPE-Bookmark-file-1>\n<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">\n<TITLE>You bookmarks</TITLE>\n<H1>You</H1>\n<DL><p>\n' + rows + '\n</DL><p>\n'


class Store:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.directory / "browser.sqlite3")
        self.connection.row_factory = sqlite3.Row
        self.connection.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS bookmarks (url TEXT PRIMARY KEY, title TEXT NOT NULL, added REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS history (id INTEGER PRIMARY KEY, url TEXT NOT NULL, title TEXT NOT NULL, visited REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, state TEXT NOT NULL, updated REAL NOT NULL);
        """)

    def get(self, key, default=None):
        row = self.connection.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        try:
            return json.loads(row[0]) if row else default
        except (ValueError, TypeError):
            return default

    def set(self, key, value):
        self.connection.execute("INSERT OR REPLACE INTO settings VALUES (?,?)", (key, json.dumps(value)))
        self.connection.commit()

    def is_bookmarked(self, url):
        return self.connection.execute("SELECT 1 FROM bookmarks WHERE url=?", (url,)).fetchone() is not None

    def bookmark(self, url, title):
        if urlsplit(url).scheme not in ("http", "https", "file"):
            return False
        self.connection.execute("INSERT OR REPLACE INTO bookmarks VALUES (?,?,?)", (url, title or url, time.time()))
        self.connection.commit()
        return True

    def remove_bookmark(self, url):
        self.connection.execute("DELETE FROM bookmarks WHERE url=?", (url,))
        self.connection.commit()

    def visit(self, url, title):
        if urlsplit(url).scheme not in ("http", "https", "file"):
            return
        self.connection.execute("INSERT INTO history(url,title,visited) VALUES (?,?,?)", (url, title or url, time.time()))
        self.connection.execute("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY visited DESC LIMIT 3000)")
        self.connection.commit()

    def items(self, table, query="", limit=200):
        if table not in ("bookmarks", "history"):
            raise ValueError("Unknown collection")
        order = "added" if table == "bookmarks" else "visited"
        pattern = "%" + query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        return self.connection.execute(
            f"SELECT * FROM {table} WHERE title LIKE ? ESCAPE '\\' OR url LIKE ? ESCAPE '\\' ORDER BY {order} DESC LIMIT ?",
            (pattern, pattern, limit),
        ).fetchall()

    def clear_history(self):
        self.connection.execute("DELETE FROM history")
        self.connection.commit()

    def suggestions(self, text, limit=7):
        if len(text.strip()) < 2:
            return []
        values = self.items("bookmarks", text, limit) + self.items("history", text, limit * 3)
        found = {}
        for row in values:
            url = saved_url(row["url"])
            if url and url not in found:
                found[url] = {"url": url, "title": row["title"]}
        return list(found.values())[:limit]

    def import_bookmarks(self, text):
        added = 0
        for url, title in parse_bookmarks_html(text):
            if not self.is_bookmarked(url):
                self.connection.execute("INSERT OR IGNORE INTO bookmarks VALUES (?,?,?)", (url, title[:1000], time.time()))
                added += 1
        self.connection.commit()
        return added

    def save_session(self, name, state):
        name = name.strip()[:100]
        if not name:
            raise ValueError("Введи название набора")
        state = clean_window_state(state)
        if not state["tabs"]:
            raise ValueError("Нет обычных вкладок для сохранения")
        try:
            self.connection.execute("INSERT INTO sessions(name,state,updated) VALUES (?,?,?)", (name, json.dumps(state), time.time()))
            self.connection.commit()
        except sqlite3.IntegrityError as error:
            raise ValueError("Такое название уже есть — выбери другое") from error

    def sessions(self):
        return self.connection.execute("SELECT id,name,updated FROM sessions ORDER BY updated DESC").fetchall()

    def load_session(self, identifier):
        row = self.connection.execute("SELECT state FROM sessions WHERE id=?", (identifier,)).fetchone()
        if not row:
            return None
        try:
            return clean_window_state(json.loads(row[0]))
        except (TypeError, ValueError):
            return None

    def delete_session(self, identifier):
        self.connection.execute("DELETE FROM sessions WHERE id=?", (identifier,))
        self.connection.commit()

    def site_zoom(self, url):
        levels = self.get("site_zoom", {})
        try:
            return max(0.5, min(3, float(levels.get(json.dumps(origin(url)), 1)))) if isinstance(levels, dict) else 1
        except (TypeError, ValueError):
            return 1

    def set_site_zoom(self, url, level):
        if urlsplit(url).scheme not in ("http", "https"):
            return
        levels = self.get("site_zoom", {})
        if not isinstance(levels, dict):
            levels = {}
        levels[json.dumps(origin(url))] = max(0.5, min(3, level))
        self.set("site_zoom", dict(list(levels.items())[-1000:]))

    def close(self):
        self.connection.close()


def home_html(store, private=False):
    engine = store.get("search_engine", "duckduckgo")
    name, action, field = SEARCH_ENGINES.get(engine, SEARCH_ENGINES["duckduckgo"])
    links = [("YouTube", "https://www.youtube.com/", "▶"), ("Википедия", "https://ru.wikipedia.org/", "W"),
             ("GitHub", "https://github.com/", "⌘"), ("Яндекс", "https://ya.ru/", "Я")]
    tiles = "".join(f'<a class="tile" href="{escape(url, quote=True)}"><b>{escape(icon)}</b><span>{escape(title)}</span></a>' for title, url, icon in links)
    bookmarks = "".join(f'<a class="bookmark" href="{escape(row["url"], quote=True)}">{escape(row["title"])}</a>' for row in store.items("bookmarks", limit=6))
    template = (ROOT / "assets" / "home.html").read_text(encoding="utf-8")
    replacements = {"ACTION": escape(action, quote=True), "FIELD": field, "ENGINE": name,
                    "TILES": tiles, "BOOKMARKS": bookmarks,
                    "MODE": "ПРИВАТНОЕ ОКНО" if private else "ТВОЁ ПРОСТРАНСТВО В ИНТЕРНЕТЕ",
                    "NOTE": "В этом окне не сохраняются история, cookies и данные сайтов после закрытия. Загрузки и добавленные закладки останутся. Приватный режим не скрывает тебя от сайтов и провайдера." if private else "Без ленты новостей и лишнего шума. Открой то, что важно тебе."}
    for key, value in replacements.items():
        template = template.replace("{{" + key + "}}", value)
    return template


def error_html(url, message):
    return f"""<!doctype html><html lang="ru"><meta charset="utf-8"><title>Не удалось открыть страницу — You</title>
    <style>body{{background:#14151c;color:#eef0f7;font:16px system-ui;max-width:650px;margin:14vh auto;padding:30px;line-height:1.7}}
    h1{{font-size:32px}}p{{color:#adb3c7;overflow-wrap:anywhere}}a{{color:#8ee7d1}}</style>
    <h1>Страница не открылась</h1><p>{escape(display_address(url))}</p><p>{escape(message)}</p>
    <p>Проверь подключение и адрес. You не отключает проверку HTTPS-сертификатов.</p>
    <a href="{escape(url, quote=True)}">Попробовать ещё раз</a></html>"""
