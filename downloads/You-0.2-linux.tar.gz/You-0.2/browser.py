"""You: a native GTK4 browser using the installed WebKitGTK engine."""

from datetime import datetime
import hashlib
from pathlib import Path
from urllib.parse import urlsplit

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("WebKit", "6.0")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk, Pango, WebKit

from core import (ROOT, SEARCH_ENGINES, Store, display_address,
                  home_html, origin, resolve_address, unique_download_path, clean_window_state)
from convenience import ConvenienceMixin

APP_ID = "local.you.Browser"


def icon_button(icon, tooltip, callback=None):
    button = Gtk.Button(icon_name=icon, tooltip_text=tooltip)
    if callback:
        button.connect("clicked", callback)
    return button


def clear_box(box):
    while box.get_first_child():
        box.remove(box.get_first_child())


class BrowserTab(Gtk.Box):
    def __init__(self, window, related=None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, vexpand=True)
        self.window = window
        self.is_home = False
        self.is_error = False
        self.failed_uri = ""
        self.page = None
        self.applying_zoom = False
        self.restore_zoom = None
        self.handlers = []
        self.find_handlers = []
        self.webview = WebKit.WebView(related_view=related) if related else WebKit.WebView(network_session=window.session)
        settings = self.webview.get_settings()
        settings.set_enable_developer_extras(True)
        settings.set_enable_media_stream(True)
        settings.set_enable_webgl(True)
        settings.set_media_playback_requires_user_gesture(True)
        self.content_stack = Gtk.Stack(vexpand=True)
        self.content_stack.add_named(self.webview, "web")
        self.error_status = Adw.StatusPage(title="Страница не открылась", icon_name="network-error-symbolic")
        retry = Gtk.Button(label="Попробовать ещё раз", halign=Gtk.Align.CENTER)
        retry.add_css_class("suggested-action")
        retry.connect("clicked", lambda b: self.open(self.failed_uri))
        self.error_status.set_child(retry)
        self.content_stack.add_named(self.error_status, "error")
        self.append(self.content_stack)
        window.app.view_windows[self.webview] = window
        for property_name in ("title", "uri", "is-loading", "estimated-load-progress", "zoom-level"):
            self._connect("notify::" + property_name, self._changed)
        self._connect("notify::zoom-level", self._zoom_changed)
        self._connect("notify::is-muted", self._audio_changed)
        self._connect("notify::is-playing-audio", self._audio_changed)
        self._connect("notify::favicon", self._favicon)
        self._connect("load-changed", self._load_changed)
        self._connect("load-failed", self._load_failed)
        self._connect("load-failed-with-tls-errors", self._tls_failed)
        self._connect("decide-policy", self._policy)
        self._connect("create", self._create)
        self._connect("close", lambda view: self.window.tab_view.close_page(self.page))
        self._connect("permission-request", self._permission)
        self._connect("mouse-target-changed", self._hover)
        self._connect("web-process-terminated", self._terminated)
        self._connect("enter-fullscreen", self._enter_fullscreen)
        self._connect("leave-fullscreen", self._leave_fullscreen)

    def _connect(self, signal, callback):
        self.handlers.append(self.webview.connect(signal, callback))

    def release(self):
        if self.webview is None:
            return
        for identifier in self.handlers:
            self.webview.disconnect(identifier)
        self.handlers.clear()
        controller = self.webview.get_find_controller()
        for identifier in self.find_handlers:
            controller.disconnect(identifier)
        self.find_handlers.clear()
        self.webview.stop_loading()
        if self.webview.get_parent() is self.content_stack:
            self.content_stack.remove(self.webview)
        # Drop the Python reference as well: a closed tab must not retain a live
        # WebKit process through its old window/page wrapper.
        self.webview = None

    def open(self, url=None):
        self.is_error = False
        self.content_stack.set_visible_child_name("web")
        self.is_home = url is None
        if url is None:
            self.webview.load_html(home_html(self.window.app.store, self.window.private), "about:blank")
        else:
            self.webview.load_uri(url)

    def _changed(self, view, _property):
        if not self.page:
            return
        uri = view.get_uri() or ""
        if uri not in ("", "about:blank"):
            self.is_home = False
        self.page.set_title("Не удалось открыть страницу" if self.is_error else ("Новая вкладка" if self.is_home else (view.get_title() or display_address(uri) or "You")))
        self.page.set_loading(view.is_loading())
        self.page.set_tooltip(display_address(uri))
        self.window.sync_toolbar()
        if not self.window.private and not self.window.closing:
            self.window.app.schedule_checkpoint()

    def _audio_changed(self, view, pspec):
        if not self.page:
            return
        muted = view.get_is_muted()
        icon = "audio-volume-muted-symbolic" if muted else ("audio-volume-high-symbolic" if view.is_playing_audio() else None)
        self.page.set_indicator_icon(Gio.ThemedIcon.new(icon) if icon else None)
        self.page.set_indicator_activatable(bool(icon))
        self.page.set_indicator_tooltip("Включить звук" if muted else "Выключить звук")
        self.window.app.schedule_checkpoint()

    def _zoom_changed(self, view, pspec):
        if self.window.closing:
            return
        if not self.applying_zoom and not view.is_loading() and not self.is_home:
            url = view.get_uri() or ""
            if self.window.private:
                self.window.private_zoom[origin(url)] = view.get_zoom_level()
            else:
                self.window.app.store.set_site_zoom(url, view.get_zoom_level())
        self.window.app.schedule_checkpoint()

    def _favicon(self, view, _property):
        if not self.page:
            return
        texture = view.get_favicon()
        self.page.set_icon(Gio.BytesIcon.new(texture.save_to_png_bytes()) if texture else Gio.ThemedIcon.new("text-html-symbolic"))

    def _load_changed(self, view, event):
        if event == WebKit.LoadEvent.STARTED:
            self.is_error = False
            self.content_stack.set_visible_child_name("web")
        if event == WebKit.LoadEvent.COMMITTED and not self.is_home:
            self.applying_zoom = True
            zoom = self.restore_zoom
            if zoom is None:
                zoom = self.window.private_zoom.get(origin(view.get_uri() or ""), 1) if self.window.private else self.window.app.store.site_zoom(view.get_uri() or "")
            view.set_zoom_level(zoom)
            self.restore_zoom = None
            self.applying_zoom = False
        if event == WebKit.LoadEvent.FINISHED:
            if not self.is_home and not self.is_error and not self.window.private and not self.window.closing:
                self.window.app.store.visit(view.get_uri() or "", view.get_title() or "")
        self.window.sync_toolbar()
        self.window.app.schedule_checkpoint()

    def show_error(self, uri, message):
        self.is_home = False
        self.is_error = True
        self.failed_uri = uri
        self.error_status.set_description(GLib.markup_escape_text(display_address(uri) + "\n\n" + message + "\n\nПроверь адрес и подключение. Проверка сертификатов HTTPS не отключается."))
        self.content_stack.set_visible_child_name("error")
        if self.page:
            self.page.set_title("Не удалось открыть страницу")
        self.window.sync_toolbar(force_address=True)

    def _load_failed(self, view, event, uri, error):
        if error.matches(WebKit.network_error_quark(), WebKit.NetworkError.CANCELLED):
            return True
        self.show_error(uri, error.message)
        return True

    def _tls_failed(self, view, uri, certificate, errors):
        self.show_error(uri, "Не удалось проверить сертификат HTTPS. Соединение заблокировано, чтобы не передавать данные неподтверждённому сайту.")
        return True

    def _terminated(self, view, reason):
        self.show_error(view.get_uri() or "about:blank", "Процесс страницы остановился. Попробуй обновить её. Причина: " + reason.value_nick)

    def _policy(self, view, decision, decision_type):
        if decision_type == WebKit.PolicyDecisionType.RESPONSE:
            if not decision.is_mime_type_supported():
                decision.download()
                return True
        if decision_type == WebKit.PolicyDecisionType.NAVIGATION_ACTION:
            action = decision.get_navigation_action()
            uri = action.get_request().get_uri()
            scheme = urlsplit(uri).scheme.lower()
            if scheme not in ("http", "https", "about", "file", "data", "blob", "javascript"):
                decision.ignore()
                if scheme in ("mailto", "tel"):
                    self.window.external_link(uri)
                else:
                    self.window.toast("Этот тип ссылки пока не поддерживается: " + scheme)
                return True
            modifiers = action.get_modifiers()
            if action.get_mouse_button() == 2 or (action.get_mouse_button() == 1 and modifiers & Gdk.ModifierType.CONTROL_MASK):
                self.window.new_tab(uri, select=False)
                decision.ignore()
                return True
        return False

    def _create(self, view, navigation):
        # Related WebViews are required for window.open and preserve the same session.
        return self.window.new_tab(related=view).webview

    def _permission(self, view, request):
        uri = view.get_uri() or ""
        site = urlsplit(uri).hostname or "Эта страница"
        if isinstance(request, WebKit.UserMediaPermissionRequest):
            devices = []
            if request.props.is_for_video_device:
                devices.append("камере")
            if request.props.is_for_audio_device:
                devices.append("микрофону")
            description = "доступ к " + " и ".join(devices)
        elif isinstance(request, WebKit.GeolocationPermissionRequest):
            description = "доступ к местоположению"
        elif isinstance(request, WebKit.ClipboardPermissionRequest):
            description = "чтение буфера обмена"
        elif isinstance(request, WebKit.PointerLockPermissionRequest):
            description = "захват указателя мыши (Esc — освободить)"
        else:
            request.deny()
            return True
        dialog = Adw.AlertDialog(heading="Разрешение для сайта", body=f"{site} запрашивает {description}. Разрешить для этой страницы?")
        dialog.add_response("deny", "Не разрешать")
        dialog.add_response("allow", "Разрешить")
        dialog.set_default_response("deny")
        dialog.set_close_response("deny")

        def answered(prompt, result, *_data):
            response = prompt.choose_finish(result)
            if response == "allow" and origin(view.get_uri() or "") == origin(uri) and self in self.window.tabs:
                request.allow()
            else:
                request.deny()

        dialog.choose(self.window, None, answered)
        return True

    def _hover(self, view, hit, modifiers):
        if self.window.current_tab() is not self:
            return
        target = hit.get_link_uri() if hit.context_is_link() else ""
        self.window.link_status.set_text(display_address(target or ""))
        self.window.link_status.set_visible(bool(target))

    def _enter_fullscreen(self, view):
        self.window.chrome.set_visible(False)
        self.window.fullscreen()
        self.window.toast("Полноэкранный режим · Esc — выйти")
        return True

    def _leave_fullscreen(self, view):
        self.window.chrome.set_visible(True)
        self.window.unfullscreen()
        return True


class DownloadItem(Gtk.Box):
    def __init__(self, window, download):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=7)
        self.add_css_class("download-item")
        self.window = window
        self.download = download
        self.path = None
        self.active = True
        self.failed = False
        self.title = Gtk.Label(label="Подготовка загрузки…", xalign=0, ellipsize=Pango.EllipsizeMode.END)
        self.progress = Gtk.ProgressBar()
        row = Gtk.Box(spacing=8)
        self.status = Gtk.Label(label="Ожидание", xalign=0, hexpand=True)
        self.status.add_css_class("dim-label")
        self.open_button = icon_button("document-open-symbolic", "Открыть скачанный файл", self._open)
        self.open_button.set_sensitive(False)
        self.cancel_button = icon_button("process-stop-symbolic", "Отменить загрузку", lambda b: download.cancel())
        row.append(self.status)
        row.append(self.open_button)
        row.append(self.cancel_button)
        self.append(self.title)
        self.append(self.progress)
        self.append(row)
        download.connect("decide-destination", self._destination)
        download.connect("notify::estimated-progress", self._progress)
        download.connect("finished", self._finished)
        download.connect("failed", self._failed)

    def _destination(self, download, suggested):
        directory = Path(GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD) or (Path.home() / "Downloads"))
        directory.mkdir(parents=True, exist_ok=True)
        self.path = unique_download_path(directory, suggested)
        # Reserve the name; never replace an existing user's file.
        while True:
            try:
                with self.path.open("xb"):
                    pass
                break
            except FileExistsError:
                self.path = unique_download_path(directory, suggested)
        download.set_allow_overwrite(True)  # Only the empty file reserved above.
        download.set_destination(str(self.path))
        self.title.set_text(self.path.name)
        return True

    def _progress(self, download, _property):
        progress = download.get_estimated_progress()
        self.progress.set_fraction(progress)
        self.status.set_text(f"{progress:.0%} · {download.get_received_data_length() / 1024:.0f} КБ")

    def _failed(self, download, error):
        self.failed = True
        self.active = False
        self.status.set_text("Ошибка: " + error.message)
        self.cancel_button.set_sensitive(False)

    def _finished(self, download):
        self.active = False
        if not self.failed:
            self.progress.set_fraction(1)
            self.status.set_text("Готово")
            self.open_button.set_sensitive(True)
            self.cancel_button.set_sensitive(False)
            self.window.toast("Загружено: " + (self.path.name if self.path else "файл"))

    def _open(self, button):
        if self.path and self.path.is_file():
            Gio.AppInfo.launch_default_for_uri(self.path.as_uri(), None)


class BrowserWindow(ConvenienceMixin, Adw.ApplicationWindow):
    def __init__(self, app, private=False, session=None):
        super().__init__(application=app, title="You · Приватное окно" if private else "You", default_width=1220, default_height=830)
        self.app = app
        self.private = private
        self.private_zoom = {}
        self.closing = False
        self.session = app.acquire_private_session(session) if private else app.session
        self.tabs = []
        self.closed_tabs = []
        self.downloads = []
        self.allow_close = False
        self.add_css_class("browser")
        self.connect("close-request", self._close_requested)
        self.overlay = Adw.ToastOverlay()
        self.set_content(self.overlay)
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.overlay.set_child(root)
        self.chrome = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        root.append(self.chrome)

        self.tab_view = Adw.TabView(vexpand=True)
        self.tab_view.connect("notify::selected-page", lambda view, pspec: self._selected())
        self.tab_view.connect("close-page", self._close_page)
        tab_bar = Adw.TabBar(view=self.tab_view, autohide=False, expand_tabs=False, hexpand=True)
        tab_bar.add_css_class("tab-toolbar")
        tab_bar.set_end_action_widget(icon_button("list-add-symbolic", "Новая вкладка · Ctrl+T", lambda b: self.new_tab()))
        header = Adw.HeaderBar()
        header.set_centering_policy(Adw.CenteringPolicy.LOOSE)
        header.set_title_widget(tab_bar)
        logo = Gtk.Button(tooltip_text="You — новая вкладка")
        logo.set_child(Gtk.Image.new_from_file(str(ROOT / "assets/icons/hicolor/scalable/apps/local.you.Browser.svg")))
        logo.get_child().set_pixel_size(25)
        logo.connect("clicked", lambda b: self.go_home())
        header.pack_start(logo)
        menu = Gtk.MenuButton(icon_name="open-menu-symbolic", tooltip_text="Меню You")
        menu.set_menu_model(self._menu())
        header.pack_end(menu)
        self.chrome.append(header)
        if private:
            banner = Gtk.Label(label="Приватное окно · история и данные сайтов не сохраняются после закрытия")
            banner.add_css_class("private-banner")
            self.chrome.append(banner)

        toolbar = Gtk.Box(spacing=6)
        toolbar.add_css_class("browser-toolbar")
        self.back = icon_button("go-previous-symbolic", "Назад · Alt+←", lambda b: self.current_view().go_back())
        self.forward = icon_button("go-next-symbolic", "Вперёд · Alt+→", lambda b: self.current_view().go_forward())
        self.reload = icon_button("view-refresh-symbolic", "Обновить / остановить · Ctrl+R", lambda b: self.reload_or_stop())
        self.address = Gtk.Entry(hexpand=True, placeholder_text="Адрес сайта или поисковый запрос")
        self.address.add_css_class("location")
        self.address.connect("activate", self._address_entered)
        self.address.connect("icon-press", self._address_icon)
        self.bookmark_button = icon_button("non-starred-symbolic", "Добавить в закладки · Ctrl+D", lambda b: self.toggle_bookmark())
        self.sidebar_button = icon_button("sidebar-show-symbolic", "Боковая панель закладок · Ctrl+B", lambda b: self.toggle_sidebar())
        self.downloads_button = Gtk.MenuButton(icon_name="folder-download-symbolic", tooltip_text="Загрузки · Ctrl+J")
        self.download_popover = Gtk.Popover()
        self.downloads_button.set_popover(self.download_popover)
        self.download_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.download_empty = Gtk.Label(label="Здесь появятся загрузки", margin_top=25, margin_bottom=25)
        self.download_box.append(self.download_empty)
        scroll = Gtk.ScrolledWindow(min_content_width=370, max_content_height=450, propagate_natural_height=True)
        scroll.set_child(self.download_box)
        self.download_popover.set_child(scroll)
        for widget in (self.sidebar_button, self.back, self.forward, self.reload, self.address, self.bookmark_button, self.downloads_button):
            toolbar.append(widget)
        self.chrome.append(toolbar)
        self.load_progress = Gtk.ProgressBar()
        self.load_progress.add_css_class("osd")
        self.chrome.append(self.load_progress)

        self.find_revealer = Gtk.Revealer()
        self.chrome.append(self.find_revealer)
        find_box = Gtk.Box(spacing=8)
        find_box.add_css_class("find-toolbar")
        self.find_entry = Gtk.SearchEntry(hexpand=True, placeholder_text="Найти на странице")
        self.find_entry.connect("search-changed", self._find)
        self.find_entry.connect("activate", lambda e: self.current_view().get_find_controller().search_next())
        self.find_count = Gtk.Label(label="")
        for widget in (self.find_entry, self.find_count,
                       icon_button("go-up-symbolic", "Предыдущее совпадение", lambda b: self.current_view().get_find_controller().search_previous()),
                       icon_button("go-down-symbolic", "Следующее совпадение", lambda b: self.current_view().get_find_controller().search_next()),
                       icon_button("window-close-symbolic", "Закрыть поиск · Esc", lambda b: self.hide_find())):
            find_box.append(widget)
        self.find_revealer.set_child(find_box)
        page_overlay = Gtk.Overlay(child=self.tab_view, vexpand=True)
        self.link_status = Gtk.Label(halign=Gtk.Align.START, valign=Gtk.Align.END, ellipsize=Pango.EllipsizeMode.MIDDLE, max_width_chars=90, visible=False)
        self.link_status.add_css_class("link-status")
        page_overlay.add_overlay(self.link_status)
        root.append(self.wrap_content(page_overlay))
        self.init_convenience()
        self._actions()

    def _menu(self):
        menu = Gio.Menu()
        for label, action in (("Новая вкладка", "new-tab"), ("Новое окно", "new-window"), ("Приватное окно", "private-window")):
            menu.append(label, "win." + action)
        collection = Gio.Menu()
        for label, action in (("Закладки", "bookmarks"), ("История", "history"), ("Загрузки", "downloads"), ("Найти на странице", "find")):
            collection.append(label, "win." + action)
        menu.append_section(None, collection)
        menu.append_section("Удобство", self.convenience_menu())
        tools = Gio.Menu()
        for label, action in (("Открыть файл…", "open-file"), ("Увеличить масштаб", "zoom-in"), ("Уменьшить масштаб", "zoom-out"),
                              ("Масштаб 100%", "zoom-reset"), ("Полный экран", "fullscreen"), ("Инструменты разработчика", "inspect"),
                              ("Настройки", "settings"), ("О браузере You", "about")):
            tools.append(label, "win." + action)
        menu.append_section(None, tools)
        return menu

    def _actions(self):
        actions = {
            "new-tab": (lambda: self.new_tab(), ["<Primary>t"]),
            "close-tab": (lambda: self.tab_view.close_page(self.tab_view.get_selected_page()), ["<Primary>w"]),
            "reopen-tab": (self.reopen_tab, ["<Primary><Shift>t"]),
            "new-window": (lambda: self.app.new_window(), ["<Primary>n"]),
            "private-window": (lambda: self.app.new_window(private=True), ["<Primary><Shift>n"]),
            "location": (self.focus_address, ["<Primary>l", "<Alt>d"]),
            "reload": (lambda: self.current_view().reload(), ["<Primary>r", "F5"]),
            "back": (lambda: self.current_view().go_back(), ["<Alt>Left"]),
            "forward": (lambda: self.current_view().go_forward(), ["<Alt>Right"]),
            "bookmark": (self.toggle_bookmark, ["<Primary>d"]),
            "bookmarks": (lambda: self.show_collection("bookmarks"), ["<Primary><Shift>o"]),
            "history": (lambda: self.show_collection("history"), ["<Primary>h"]),
            "downloads": (lambda: self.downloads_button.popup(), ["<Primary>j"]),
            "find": (self.show_find, ["<Primary>f"]),
            "escape": (self.escape, ["Escape"]),
            "open-file": (self.open_file, ["<Primary>o"]),
            "zoom-in": (lambda: self.zoom(0.1), ["<Primary>plus", "<Primary>equal"]),
            "zoom-out": (lambda: self.zoom(-0.1), ["<Primary>minus"]),
            "zoom-reset": (lambda: self.current_view().set_zoom_level(1), ["<Primary>0"]),
            "fullscreen": (self.toggle_fullscreen, ["F11"]),
            "inspect": (lambda: self.current_view().get_inspector().show(), ["F12"]),
            "settings": (self.show_settings, []),
            "about": (self.show_about, []),
        }
        actions.update(self.convenience_actions())
        for name, (callback, accelerators) in actions.items():
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", lambda a, value, function=callback: function())
            self.add_action(action)
            self.app.set_accels_for_action("win." + name, accelerators)

    def current_tab(self):
        page = self.tab_view.get_selected_page()
        return page.get_child() if page else None

    def current_view(self):
        tab = self.current_tab()
        return tab.webview if tab else None

    def new_tab(self, url=None, select=True, related=None, state=None):
        tab = BrowserTab(self, related=related)
        self.tabs.append(tab)
        tab.page = self.tab_view.append(tab)
        tab.page.set_title("Новая вкладка")
        tab.page.set_icon(Gio.ThemedIcon.new("text-html-symbolic"))
        if state:
            self.tab_view.set_page_pinned(tab.page, bool(state.get("pinned")))
            tab.webview.set_is_muted(bool(state.get("muted")))
            tab.restore_zoom = max(0.5,min(3,float(state.get("zoom",1))))
        controller = tab.webview.get_find_controller()
        tab.find_handlers.append(controller.connect("found-text", lambda controller, count: tab.window.find_count.set_text(f"Совпадений: {count}") if tab.window.current_tab() is tab else None))
        tab.find_handlers.append(controller.connect("failed-to-find-text", lambda controller: tab.window.find_count.set_text("Нет совпадений") if tab.window.current_tab() is tab else None))
        if select:
            self.tab_view.set_selected_page(tab.page)
        if related is None:
            tab.open(url)
        if select and url is None and related is None:
            GLib.idle_add(self.focus_address)
        self.app.schedule_checkpoint()
        return tab

    def _selected(self):
        if not self.current_tab():
            return
        self.hide_find()
        self.link_status.set_visible(False)
        self.sync_toolbar(force_address=True)
        self.app.schedule_checkpoint()

    def sync_toolbar(self, force_address=False):
        if self.closing:
            return
        tab = self.current_tab()
        if not tab:
            return
        view = tab.webview
        uri = tab.failed_uri if tab.is_error else (view.get_uri() or "")
        if force_address or not self.address_has_focus():
            self._syncing_address = True
            self.address.set_text("" if tab.is_home else display_address(uri))
            self._syncing_address = False
        self.back.set_sensitive(view.can_go_back())
        self.forward.set_sensitive(view.can_go_forward())
        self.reload.set_icon_name("process-stop-symbolic" if view.is_loading() else "view-refresh-symbolic")
        self.load_progress.set_fraction(view.get_estimated_load_progress())
        self.load_progress.set_visible(view.is_loading())
        bookmarked = self.app.store.is_bookmarked(uri)
        self.bookmark_button.set_icon_name("starred-symbolic" if bookmarked else "non-starred-symbolic")
        self.bookmark_button.set_sensitive(not tab.is_home and not tab.is_error and urlsplit(uri).scheme in ("http", "https", "file"))
        secure, certificate, errors = view.get_tls_info()
        secure = bool(secure and not errors and not tab.is_error)
        icon = "channel-secure-symbolic" if secure else ("dialog-warning-symbolic" if uri.startswith("https:") else "system-search-symbolic")
        self.address.set_icon_from_icon_name(Gtk.EntryIconPosition.PRIMARY, icon)
        self.address.set_icon_tooltip_text(Gtk.EntryIconPosition.PRIMARY, "HTTPS: сертификат проверен" if secure else "Адрес страницы · HTTP не шифрует соединение")

    def focus_address(self):
        self.address.grab_focus()
        self.address.select_region(0, -1)
        return False

    def _address_entered(self, entry):
        self.suggestions_popover.popdown()
        url = resolve_address(entry.get_text(), self.app.store.get("search_engine", "duckduckgo"))
        self.open_url(url)

    def _address_icon(self, entry, position):
        self.toast(entry.get_icon_tooltip_text(position) or "You")

    def open_url(self, url):
        if not self.current_tab():
            self.new_tab(url)
        else:
            self.current_tab().open(url)
        self.current_view().grab_focus()
        self.sync_toolbar(force_address=True)

    def go_home(self):
        self.open_url(None)
        self.focus_address()

    def reload_or_stop(self):
        if self.current_tab().is_error:
            self.current_tab().open(self.current_tab().failed_uri)
            return
        view = self.current_view()
        view.stop_loading() if view.is_loading() else view.reload()

    def _close_page(self, tab_view, page):
        tab = page.get_child()
        if tab_view.get_n_pages() == 1:
            tab_view.close_page_finish(page, False)
            self.close()
            return True
        self.closed_tabs.append(self.tab_state(tab))
        self.closed_tabs = self.closed_tabs[-50:]
        self.app.view_windows.pop(tab.webview, None)
        tab.release()
        self.tabs.remove(tab)
        tab_view.close_page_finish(page, True)
        self.app.schedule_checkpoint()
        return True

    def reopen_tab(self):
        if self.closed_tabs:
            state = self.closed_tabs.pop()
            self.new_tab(state["url"], state=state)

    def toggle_bookmark(self):
        tab = self.current_tab()
        if not tab or tab.is_home or tab.is_error:
            return
        url = tab.webview.get_uri() or ""
        if self.app.store.is_bookmarked(url):
            self.app.store.remove_bookmark(url)
            self.toast("Закладка удалена")
        elif self.app.store.bookmark(url, tab.webview.get_title()):
            self.toast("Добавлено в закладки")
        self.sync_toolbar()
        self.app.refresh_bookmarks()

    def show_find(self):
        self.find_revealer.set_reveal_child(True)
        self.find_entry.grab_focus()

    def hide_find(self):
        self.find_revealer.set_reveal_child(False)
        if self.current_view():
            self.current_view().get_find_controller().search_finish()
        self.find_count.set_text("")

    def _find(self, entry):
        text = entry.get_text()
        controller = self.current_view().get_find_controller()
        if text:
            controller.search(text, WebKit.FindOptions.CASE_INSENSITIVE | WebKit.FindOptions.WRAP_AROUND, 10000)
        else:
            controller.search_finish()
            self.find_count.set_text("")

    def escape(self):
        if self.suggestions_popover.get_visible():
            self.suggestions_popover.popdown()
        elif self.is_fullscreen():
            self.unfullscreen()
            self.chrome.set_visible(True)
        elif self.find_revealer.get_reveal_child():
            self.hide_find()
            self.current_view().grab_focus()
        elif self.current_view().is_loading():
            self.current_view().stop_loading()

    def toggle_fullscreen(self):
        self.unfullscreen() if self.is_fullscreen() else self.fullscreen()

    def zoom(self, delta):
        value = max(0.5, min(3, round(self.current_view().get_zoom_level() + delta, 1)))
        self.current_view().set_zoom_level(value)
        self.toast(f"Масштаб {value:.0%}")

    def toast(self, text):
        self.overlay.add_toast(Adw.Toast.new(GLib.markup_escape_text(text)))

    def _dialog(self, title):
        dialog = Adw.Dialog(title=title, content_width=600, content_height=550)
        toolbar = Adw.ToolbarView()
        toolbar.add_top_bar(Adw.HeaderBar(title_widget=Adw.WindowTitle(title=title)))
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=13)
        content.add_css_class("collection-body")
        toolbar.set_content(content)
        dialog.set_child(toolbar)
        return dialog, content

    def show_collection(self, collection):
        title = "Закладки" if collection == "bookmarks" else "История"
        dialog, content = self._dialog(title)
        search = Gtk.SearchEntry(placeholder_text="Поиск по названию и адресу")
        content.append(search)
        rows = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        rows.add_css_class("boxed-list")
        scroll = Gtk.ScrolledWindow(vexpand=True)
        scroll.set_child(rows)
        content.append(scroll)
        if self.private and collection == "history":
            content.prepend(Gtk.Label(label="Показана обычная история. Страницы приватного окна в неё не записываются.", wrap=True))

        def rebuild(*args):
            clear_box(rows)
            items = self.app.store.items(collection, search.get_text())
            if not items:
                rows.append(Gtk.Label(label="Пока ничего нет", margin_top=25, margin_bottom=25))
            for item in items:
                row = Adw.ActionRow(title=item["title"], subtitle=display_address(item["url"]), use_markup=False, activatable=True)
                row.set_title_lines(1)
                row.set_subtitle_lines(1)
                row.connect("activated", lambda row, url=item["url"]: (self.open_url(url), dialog.close()))
                if collection == "bookmarks":
                    def remove(button, url=item["url"]):
                        self.app.store.remove_bookmark(url)
                        rebuild()
                        self.app.refresh_bookmarks()
                    row.add_suffix(icon_button("user-trash-symbolic", "Удалить закладку", remove))
                    row.add_suffix(icon_button("document-edit-symbolic", "Изменить закладку", lambda button, value=dict(item): self.edit_bookmark(value)))
                else:
                    row.add_suffix(Gtk.Label(label=datetime.fromtimestamp(item["visited"]).strftime("%d.%m %H:%M")))
                rows.append(row)

        search.connect("search-changed", rebuild)
        rebuild()
        dialog.present(self)

    def show_settings(self):
        dialog, content = self._dialog("Настройки You")
        group = Adw.PreferencesGroup(title="Поиск")
        engines = list(SEARCH_ENGINES)
        model = Gtk.StringList.new([SEARCH_ENGINES[key][0] for key in engines])
        combo = Adw.ComboRow(title="Поисковая система", model=model)
        current = self.app.store.get("search_engine", "duckduckgo")
        combo.set_selected(engines.index(current) if current in engines else 0)
        combo.connect("notify::selected", lambda row, pspec: self.app.store.set("search_engine", engines[row.get_selected()]))
        group.add(combo)
        content.append(group)
        startup = Adw.PreferencesGroup(title="Запуск")
        restore = Adw.SwitchRow(title="Восстанавливать обычные окна и вкладки", subtitle="Адреса, закрепление и звук. Приватные окна и заполненные формы не сохраняются.")
        restore.set_active(bool(self.app.store.get("restore_session", True)))
        restore.connect("notify::active", lambda row,pspec:self.app.store.set("restore_session",row.get_active()))
        startup.add(restore)
        content.append(startup)
        privacy = Adw.PreferencesGroup(title="Данные на этом компьютере")
        clear_button = Gtk.Button(label="Очистить", valign=Gtk.Align.CENTER)
        history_row = Adw.ActionRow(title="Очистить историю", subtitle="Закладки, cookies и загрузки останутся")
        history_row.add_suffix(clear_button)
        clear_button.connect("clicked", lambda b: self.confirm_clear_history())
        privacy.add(history_row)
        content.append(privacy)
        profile = Gtk.Label(label="Профиль: " + str(self.app.store.directory), wrap=True, selectable=True, xalign=0)
        profile.add_css_class("dim-label")
        content.append(profile)
        note = Gtk.Label(label="Приватное окно не сохраняет историю и данные сайтов после закрытия. Оно не скрывает IP-адрес. Скачанные файлы и добавленные вручную закладки сохраняются.", wrap=True, xalign=0)
        content.append(note)
        dialog.present(self)

    def confirm_clear_history(self):
        prompt = Adw.AlertDialog(heading="Удалить историю посещений?", body="Это действие нельзя отменить. Закладки и cookies не затрагиваются.")
        prompt.add_response("cancel", "Отмена")
        prompt.add_response("clear", "Удалить")
        prompt.set_response_appearance("clear", Adw.ResponseAppearance.DESTRUCTIVE)
        prompt.set_close_response("cancel")
        prompt.set_default_response("cancel")

        def done(dialog, result, *_data):
            if dialog.choose_finish(result) == "clear":
                self.app.store.clear_history()
                self.toast("История очищена")
        prompt.choose(self, None, done)

    def show_about(self):
        dialog = Adw.AboutDialog(application_name="You", application_icon=APP_ID, version="0.2", developer_name="Локальный проект")
        dialog.set_comments(f"Браузер для Linux. Настоящие вкладки, закладки и приватные окна.\nWebKitGTK {WebKit.get_major_version()}.{WebKit.get_minor_version()}.{WebKit.get_micro_version()}\nДвижок обновляется вместе с системой.")
        dialog.present(self)

    def open_file(self):
        chooser = Gtk.FileDialog(title="Открыть файл в You")
        def selected(dialog, result, *_data):
            try:
                file = dialog.open_finish(result)
                self.open_url(file.get_uri())
            except GLib.Error:
                pass  # Dialog cancellation is not an error to show the user.
        chooser.open(self, None, selected)

    def external_link(self, uri):
        prompt = Adw.AlertDialog(heading="Открыть другое приложение?", body=display_address(uri))
        prompt.add_response("cancel", "Отмена")
        prompt.add_response("open", "Открыть")
        prompt.set_close_response("cancel")
        def done(dialog, result, *_data):
            if dialog.choose_finish(result) == "open":
                try:
                    Gio.AppInfo.launch_default_for_uri(uri, None)
                except GLib.Error as error:
                    self.toast(error.message)
        prompt.choose(self, None, done)

    def add_download(self, download):
        self.download_empty.set_visible(False)
        item = DownloadItem(self, download)
        self.downloads.append(item)
        self.download_box.append(item)
        self.downloads_button.popup()
        return item

    def _close_requested(self, window):
        if self.closing:
            return False
        active = [item for item in self.downloads if item.active]
        if active and not self.allow_close:
            prompt = Adw.AlertDialog(heading="Загрузки ещё идут", body="Закрыть окно и отменить незавершённые загрузки?")
            prompt.add_response("stay", "Остаться")
            prompt.add_response("close", "Отменить загрузки и закрыть")
            prompt.set_close_response("stay")
            prompt.set_default_response("stay")
            prompt.set_response_appearance("close", Adw.ResponseAppearance.DESTRUCTIVE)
            def done(dialog, result, *_data):
                if dialog.choose_finish(result) == "close":
                    self.allow_close = True
                    for item in active:
                        item.download.cancel()
                    self.close()
            prompt.choose(self, None, done)
            return True
        self.app.window_closing(self)
        self.suggestions_popover.popdown()
        self.suggestions_popover.unparent()
        for tab in self.tabs:
            self.app.view_windows.pop(tab.webview, None)
            tab.release()
        self.tabs.clear()
        if self.private:
            self.app.release_private_session(self.session)
        return False


class YouApplication(Adw.Application):
    def __init__(self, profile=None):
        default_profile = Path(GLib.get_user_data_dir()) / "you-browser"
        self.profile = Path(profile).resolve() if profile else default_profile
        application_id = APP_ID if not profile else APP_ID + ".p" + hashlib.sha256(str(self.profile).encode()).hexdigest()[:12]
        super().__init__(application_id=application_id, flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.add_main_option("private", ord("p"), GLib.OptionFlags.NONE, GLib.OptionArg.NONE, "Открыть приватное окно", None)
        self.store = Store(self.profile)
        self.view_windows = {}
        self.private_sessions = {}
        self.checkpoint_source = None
        self.stopping = False
        self.session = WebKit.NetworkSession.new(str(self.profile / "websites"), str(self.profile / "cache"))
        self.session.get_cookie_manager().set_persistent_storage(str(self.profile / "cookies.sqlite3"), WebKit.CookiePersistentStorage.SQLITE)
        self.session.connect("download-started", self._download_started)

    def do_startup(self):
        Adw.Application.do_startup(self)
        if GLib.get_application_name() != "You":
            GLib.set_application_name("You")
        Adw.StyleManager.get_default().set_color_scheme(Adw.ColorScheme.PREFER_DARK)
        icon_theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
        icon_theme.add_search_path(str(ROOT / "assets/icons"))
        Gtk.Window.set_default_icon_name(APP_ID)
        provider = Gtk.CssProvider()
        provider.load_from_path(str(ROOT / "assets/browser.css"))
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def do_activate(self):
        window = self.get_active_window()
        if window:
            window.present()
        else:
            if not self.restore_last_session():
                self.new_window()

    def do_command_line(self, command_line):
        arguments = [value for value in command_line.get_arguments()[1:] if value not in ("--private", "-p")]
        private = command_line.get_options_dict().contains("private")
        if arguments or private:
            self.new_window(private=private, addresses=arguments)
        else:
            self.activate()
        return 0

    def new_window(self, private=False, addresses=None, empty=False, session=None):
        window = BrowserWindow(self, private=private, session=session)
        if not empty:
            for address in addresses or [None]:
                window.new_tab(resolve_address(address, self.store.get("search_engine", "duckduckgo")) if address else None)
        window.present()
        return window

    def acquire_private_session(self, session=None):
        session = session or WebKit.NetworkSession.new_ephemeral()
        if not session.is_ephemeral():
            raise ValueError("Приватному окну нужна непостоянная сетевая сессия")
        if session in self.private_sessions:
            self.private_sessions[session][1] += 1
        else:
            identifier = session.connect("download-started",self._download_started)
            self.private_sessions[session] = [identifier,1]
        return session

    def release_private_session(self, session):
        record = self.private_sessions.get(session)
        if record:
            record[1] -= 1
            if record[1] == 0:
                session.disconnect(record[0])
                del self.private_sessions[session]

    def refresh_bookmarks(self):
        for window in self.get_windows():
            if hasattr(window,"tabs") and not window.closing:
                window.refresh_sidebar()
                window.sync_toolbar()

    def schedule_checkpoint(self):
        if self.stopping or self.checkpoint_source is not None:
            return
        def save():
            self.checkpoint_source = None
            self.checkpoint()
            return False
        self.checkpoint_source = GLib.timeout_add(350,save)

    def cancel_checkpoint(self):
        if self.checkpoint_source is not None:
            GLib.source_remove(self.checkpoint_source)
            self.checkpoint_source = None

    def checkpoint(self, windows=None):
        if self.stopping:
            return
        windows = self.get_windows() if windows is None else windows
        states = [window.window_state() for window in windows
                  if hasattr(window,"tabs") and not window.private and not window.closing and window.tabs]
        if states:
            self.store.set("last_session", {"version":1,"windows":states})

    def window_closing(self, window):
        if window.closing:
            return
        if not window.private:
            others = [candidate for candidate in self.get_windows()
                      if candidate is not window and hasattr(candidate,"tabs") and not candidate.private and not candidate.closing and candidate.tabs]
            self.checkpoint(others or [window])
        window.closing = True

    def restore_last_session(self):
        if not self.store.get("restore_session",True):
            return False
        snapshot = self.store.get("last_session",{})
        if not isinstance(snapshot,dict) or snapshot.get("version") != 1 or not isinstance(snapshot.get("windows"),list):
            return False
        states = [clean_window_state(value) for value in snapshot["windows"][:8]]
        states = [value for value in states if value["tabs"]]
        if not states:
            return False
        for state in states:
            window = self.new_window(empty=True)
            window.restore_state(state)
        return True

    def _download_started(self, session, download):
        view = download.get_web_view()
        window = self.view_windows.get(view) or self.get_active_window()
        if window:
            window.add_download(download)

    def do_shutdown(self):
        self.cancel_checkpoint()
        self.checkpoint()
        self.stopping = True
        self.store.close()
        Adw.Application.do_shutdown(self)
