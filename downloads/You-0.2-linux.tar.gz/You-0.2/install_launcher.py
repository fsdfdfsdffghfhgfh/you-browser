#!/usr/bin/env python3
"""Install a per-user menu entry, without changing the default browser."""

import os
from pathlib import Path
import shutil
import subprocess


def quote_argument(value):
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$").replace("`", "\\`") + '"'


def main():
    root = Path(__file__).resolve().parent
    applications = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share")) / "applications"
    applications.mkdir(parents=True, exist_ok=True)
    destination = applications / "local.you.Browser.desktop"
    executable = quote_argument(root / "run.sh")
    content = f"""[Desktop Entry]
Type=Application
Version=1.0
Name=You
GenericName=Веб-браузер
Comment=Твоё пространство в интернете
Exec={executable} %U
Icon={root / 'assets/icons/hicolor/scalable/apps/local.you.Browser.svg'}
Terminal=false
StartupNotify=true
StartupWMClass=local.you.Browser
Categories=Network;WebBrowser;
MimeType=text/html;application/xhtml+xml;x-scheme-handler/http;x-scheme-handler/https;
Actions=Private;

[Desktop Action Private]
Name=Приватное окно
Exec={executable} --private
"""
    if destination.exists() and destination.read_text() != content:
        print(f"Не заменяю существующий файл: {destination}")
        return 1
    destination.write_text(content)
    if shutil.which("update-desktop-database"):
        subprocess.run(["update-desktop-database", str(applications)], check=False)
    print(f"You добавлен в меню приложений: {destination}")
    print("Браузер по умолчанию не изменён.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
